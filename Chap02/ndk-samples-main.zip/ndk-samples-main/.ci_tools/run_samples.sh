#!/bin/bash

# TBD: load apks on emulator
#
